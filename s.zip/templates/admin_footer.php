</div>
</main>

<footer class="main-footer" style="background-color: #f1f5f9; color: #64748b; border-top: 1px solid #e2e8f0;">
    <div class="container">
        <p>Admin Panel</p>
    </div>
</footer>

</body>
</html>